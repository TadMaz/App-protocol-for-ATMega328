
#include "app_routing.h"

AppRouter::AppRouter()
{
    for (int i = 0; i<ROUTER_TABLE_LENGTH; i++){

        Rssi[i] = 0;
        DestinationID[i] = 0;
        DistanceToGateway[i] = 0;
    }
}