//Header for routing in sensor node
#ifndef APPRouter_h
#define APPRouter_h

#include <stdint.h>
#define ROUTER_TABLE_LENGTH 5

class AppRouter
{
    public:

    int16_t Rssi[ROUTER_TABLE_LENGTH];
    uint16_t DestinationID [ROUTER_TABLE_LENGTH];
    uint8_t DistanceToGateway [ROUTER_TABLE_LENGTH];

    AppRouter();
    ~AppRouter();
};

#endif

